package com.login.controller;

public @interface EnableWebSecurity {

}
