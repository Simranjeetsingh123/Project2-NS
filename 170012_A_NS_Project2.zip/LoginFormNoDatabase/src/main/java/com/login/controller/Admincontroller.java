package com.login.controller;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.SessionAttributes;
//
//import com.login.service.LoginService;
//
//@Controller
//@SessionAttributes("name")
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class Admincontroller extends WebSecurityConfigurerAdapter {
	@Autowired
//	public void configureGlobal(AuthenticationManagerBuilder authenticationMgr) throws Exception {
//		authenticationMgr.inMemoryAuthentication()
//			.withUser("jduser").password("jdu@123").authorities("ROLE_USER")
//			.and()
//			.withUser("jdadmin").password("jda@123").authorities("ROLE_USER","ROLE_ADMIN");
//	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		
		http.authorizeRequests()
			.antMatchers("/homePage").access("hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
			.antMatchers("/userPage").access("hasRole('ROLE_USER')")
			.antMatchers("/adminPage").access("hasRole('ROLE_ADMIN')")
			.and()
				.formLogin().loginPage("/loginPage")
				.defaultSuccessUrl("/homePage")
				.failureUrl("/loginPage?error")
				.usernameParameter("username").passwordParameter("password")				
			.and()
				.logout().logoutSuccessUrl("/loginPage?logout"); 
		
	}
//	 @Autowired
//	    LoginService service;
//	   // LoginService serviceclient;
//
//	    @RequestMapping(value="/login", method = RequestMethod.GET)
//	    public String showLoginPage(ModelMap model){
//	        return "login";
//	    }
//
//	    @RequestMapping(value="/login", method = RequestMethod.POST)
//	    public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password){
//
//	        boolean isValidUser = service.validateUser1(name, password);
//
//	        if (!isValidUser) {
//	            model.put("errorMessage", "Invalid Credentials");
//	            return "login";
//	        }
//
//	        model.put("name", name);
//	        model.put("password", password);
//
//	        return "welcome";
//	    }
}
