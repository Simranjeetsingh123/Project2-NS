package com.login.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    public boolean validateUser(String userid, String password) {
        // mmdu, 12345
        return userid.equalsIgnoreCase("mmdu")
                && password.equalsIgnoreCase("12345");
    }
//    public boolean validateUser1(String userid, String password) {
//        // mmu, 1234
//        return userid.equalsIgnoreCase("Admin")
//                && password.equalsIgnoreCase("123");
//}
}